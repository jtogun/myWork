SET STORAGE_ENGINE = INNODB;

### USE CompanyDB
USE world_news_corp_;

#query 1
select aut_Fname, aut_Lname, aut_Age from Author; 
#query 2
select AVG(aut_Age) from Author where aut_Gender = 'M'; #and aut_Age = 'Average Age of male authors'
#query 3
#select aut_Fname, aut_Lname, MAX(aut_Salary) from Author;# from Author;
select aut_Fname, aut_Lname, aut_Salary from Author where aut_Salary = (select MAX(aut_Salary) from author);
#select * from (select * from Author order by ''
#query 4
select aut_Fname, aut_lname from author where aut_ni not in( select na_aut_NI from NewsArticle);# where na_aut_NI);
#select * from NewsArticle where na_aut_NI in(select aut_NI from Author);
# not exists (select * from NewsArticle where na_aut_NI );
#query 5
select na_Title, na_Topic, aut_Fname, aut_Lname from NewsArticle inner join Author on NewsArticle.na_aut_NI = Author.aut_NI where na_Article rlike('David Cameron') or na_Article rlike ('George Clooney');
