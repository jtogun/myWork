SET STORAGE_ENGINE = INNODB;

## This is a script file, which will be executed in MySQL using batch mode

## Lines that start with # are comments

# Create a database (remember to drop it if it exists first)
DROP DATABASE IF EXISTS world_news_corp_;
CREATE DATABASE world_news_corp_;
USE world_news_corp_;

# Author
CREATE TABLE Author (
	aut_NI BIGINT NOT NULL,
	aut_Fname VARCHAR(30) NOT NULL,
	aut_Lname VARCHAR(30) NOT NULL,
	aut_Gender ENUM('M', 'F') NOT NULL,
	aut_Age INT UNSIGNED NOT NULL,
	aut_Salary DECIMAL (8,2) NOT NULL,
	aut_CountryTheyLiveIn VARCHAR(30) NOT NULL,
	PRIMARY KEY (aut_NI)
    );

#News article
CREATE TABLE NewsArticle (
	na_ArticleID INT NULL AUTO_INCREMENT,
    na_Title VARCHAR(50) NOT NULL,
    na_Article VARCHAR(250) NOT NULL,
    na_TimeWritten DATETIME NOT NULL,
    na_CountryItsAbout VARCHAR(30) NOT NULL,
    na_Topic VARCHAR(40) NOT NULL,
    na_aut_NI BIGINT NOT NULL,
    
    #na_timeliked INT UNSIGNED,
    PRIMARY KEY (na_ArticleID),
    FOREIGN KEY (na_aut_NI) REFERENCES Author(aut_NI) 
    #FOREIGN KEY (na_timeliked) REFERENCES Liking(timeliked) ON DELETE CASCADE
    );
    
#Commenter
CREATE TABLE Commenter (
	com_CommentID INT NOT NULL,
	com_UserName VARCHAR (40) NOT NULL,
    com_TimeCommented DATETIME NOT NULL,
    com_Comment VARCHAR(100) NOT NULL,
    com_na_ID INT NOT NULL,
    PRIMARY KEY (com_CommentID),
	FOREIGN KEY (com_na_ID) REFERENCES NewsArticle(na_ArticleID)
    );

#like
CREATE TABLE LikedArticle (
	likedID INT NOT NULL,
    theArticleLikedID INT NOT NULL,
    timeliked DATETIME NOT NULL,
    amountOfTimesLiked INT NOT NULL,
   # timeLikedID INT NULL AUTO_INCREMENT,
    PRIMARY KEY (likedID),
	FOREIGN KEY (theArticleLikedID) REFERENCES NewsArticle(na_ArticleID) ON DELETE CASCADE
    );
    
#INSERT INTO NewsArticle values('Europe crackdown on jihadist network', 1,  'Police target 17 people in raids in several European countries on suspicion of links to a jihadist network.','1000-01-01 00:00:00', 'England', 'Politics',1987234920 );
   
#inserting author data
INSERT INTO Author values(1987234920,'Adam','Zapel', 'M', 34 , 20000, 'England');
INSERT INTO Author values(9348098234,'Jack','Pott', 'M', 32 , 32000, 'Scotland');
INSERT INTO Author values(4564547547,'Joe','King', 'M', 23, 14000, 'India');
INSERT INTO Author values(5654674575,'Matt','Tress', 'M', 45 , 24000, 'India');
INSERT INTO Author values(5675675675,'Orson','Carte', 'M', 56 , 40000, 'Ireland');
INSERT INTO Author values(7775656765,'Warren','Peace', 'M', 33 , 19000, 'England');
INSERT INTO Author values(8964334324,'Anne','Teak', 'F', 18 , 20000, 'America');
INSERT INTO Author values(6612355667,'Anna','Conda', 'F', 19 , 49000, 'France');
INSERT INTO Author values(3456456457,'Cara','Van', 'F', 42 , 32000, 'France');
INSERT INTO Author values(1875432325,'Gail','Force', 'F', 53 , 34000, 'America');
INSERT INTO Author values(1134576877,'Helen','Back', 'F', 37 , 20000, 'England');
INSERT INTO Author values(2345457654,'Hazel','Nutt', 'F', 43 , 34000, 'Indonesia');


#inserting newsarticle data
INSERT INTO NewsArticle (na_Title, na_Article, na_TimeWritten, na_CountryItsAbout, na_Topic, na_aut_NI)values('Europe crackdown on jihadist network', 'Police target 17 people in raids in several European countries on suspicion of links to a jihadist network.',now(), 'England', 'Politics', 1987234920);
INSERT INTO NewsArticle (na_Title, na_Article, na_TimeWritten, na_CountryItsAbout, na_Topic, na_aut_NI)values('Modi visit historic opportunity for UK', 'Indian prime minister arrives in the UK for a three day visit, described by David Cameron as a historic opportunity for both countries.',now(), 'India', 'Politics', 9348098234);
INSERT INTO NewsArticle (na_Title, na_Article, na_TimeWritten, na_CountryItsAbout, na_Topic, na_aut_NI)values('Sweden brings in migrant border checks', 'Sweden brings in temporary border checks to control the flow of migrants into the country, as an EU Africa summit continues.',now(),'Sweeden', 'Politics', 5675675675);
INSERT INTO NewsArticle (na_Title, na_Article, na_TimeWritten, na_CountryItsAbout, na_Topic, na_aut_NI)values('Apple apologises after racism outcry', 'Apple apologises to six schoolboys who were asked to leave one of their shops in Australia, in what the students described as a racist incident.', now(),'Australia', 'Financial',7775656765);
INSERT INTO NewsArticle (na_Title, na_Article, na_TimeWritten, na_CountryItsAbout, na_Topic, na_aut_NI)values('HMRC reveals tax office shake-up','The UKs tax authority will close 137 local offices and replace them with 13 regional centres, raising fears over job losses.',now(),'England','Financial', 1134576877);
INSERT INTO NewsArticle (na_Title, na_Article, na_TimeWritten, na_CountryItsAbout, na_Topic, na_aut_NI)values('Film star visits cafe for homeless','Hollywood star George Clooney visits a sandwich shop which helps homeless people during a visit to Edinburgh.',now(),'Scotland','Entertainment',1987234920);
INSERT INTO NewsArticle (na_Title, na_Article, na_TimeWritten, na_CountryItsAbout, na_Topic, na_aut_NI)values('Rolls-Royce shares dive on profit woes','Shares in aerospace group RollsRoyce sink after it warns that its profits will be hit by sharply weaker demand.',now(),'England','Financial',1134576877);
INSERT INTO NewsArticle (na_Title, na_Article, na_TimeWritten, na_CountryItsAbout, na_Topic, na_aut_NI)values('Ex-MPs GBP13,700 on shredding and skips','The Independent Parliamentary Standards Authority releases expenses claims for 182 MPs who left the Commons at the election - with GBP705,000 spent on closing down their offices.',now(),'England','Politics',1134576877);
INSERT INTO NewsArticle (na_Title, na_Article, na_TimeWritten, na_CountryItsAbout, na_Topic, na_aut_NI)values('Action needed to protect UK coast','The UK is ignoring known risks of flood and erosion at the coast and immediate action is needed to manage the threats, the National Trust warns.',now(),'England','Science',3456456457);
INSERT INTO NewsArticle (na_Title, na_Article, na_TimeWritten, na_CountryItsAbout, na_Topic, na_aut_NI)values('Venus twin excites astronomers','Astronomers hunting distant worlds say they have made one of their most significant discoveries to date, what could be a kind of hot twin to our Venus.',now(),'America','Science',2345457654);

#inserting comments
#INSERT INTO Commenter(com_UserName, com_Timecommented, com_comment) values('JacksonGray96', now(),'Great post Adam Zapel!');#,1987234920);
INSERT INTO Commenter values(1,'mikeFire89', now(), 'What a good article, well done Adam Zapel',1);
INSERT INTO Commenter values(2,'jessTheBest', now(), 'lovely work Jack Pott',2);
INSERT INTO Commenter values(3,'tj', now(), 'sick post Orson Carte, really liking it',3);
INSERT INTO Commenter values(4,'amy95', now(), 'really feeling the article Warren Peace',4);
INSERT INTO Commenter values(5,'philRay', now(), 'interesting post Helen Back',5);
INSERT INTO Commenter values(6,'JacksonGray96', now(),'Great post Joe King!',1);#,1987234920);

#inserting into liking
#INSERT INTO likedArticle (likedArticleID, timeliked)values(2,now());
INSERT INTO likedArticle (likedID,theArticleLikedID, timeliked, amountOfTimesLiked)values(1,2,now(),6);
INSERT INTO likedArticle (likedID,theArticleLikedID, timeliked, amountOfTimesLiked)values(2,4,now(),2);
INSERT INTO likedArticle (likedID,theArticleLikedID, timeliked, amountOfTimesLiked)values(3,6,now(),1);
INSERT INTO likedArticle (likedID,theArticleLikedID, timeliked, amountOfTimesLiked)values(4,9,now(),5);
#INSERT INTO likedArticle (likedArticleID, timeliked)values(4,now());

